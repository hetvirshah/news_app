class News {
  String? id;
  String? title;
  String? description;
  String? url;
  String? author;
  String? image;
  String? language;
  List<String>? category;
  String? published;

  News(
      {this.id,
      this.title,
      this.description,
      this.url,
      this.author,
      this.image,
      this.language,
      this.category,
      this.published});

  News.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    description = json['description'];
    url = json['url'];
    author = json['author'];
    image = json['image'];
    language = json['language'];
    category = json['category'].cast<String>();
    published = json['published'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['description'] = this.description;
    data['url'] = this.url;
    data['author'] = this.author;
    data['image'] = this.image;
    data['language'] = this.language;
    data['category'] = this.category;
    data['published'] = this.published;
    return data;
  }
}

class Region {
  final String name;
  final String queryCode;

  Region({required this.name, required this.queryCode});

  factory Region.fromJson(Map<String, dynamic> json) {
    return Region(
      name: json['name'],
      queryCode: json['queryCode'],
    );
  }
}

class Language {
  final String name;
  final String queryCode;

  Language({required this.name, required this.queryCode});

  factory Language.fromJson(Map<String, dynamic> json) {
    return Language(
      name: json['name'],
      queryCode: json['queryCode'],
    );
  }
}

class Category {
  final String name;

  Category({required this.name});

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      name: json['name'],
    );
  }
}
