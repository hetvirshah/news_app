// lib/services/news_service.dart
import 'package:dio/dio.dart';

class NewsService {
  final Dio _dio = Dio();

  final String apiKey = 'bUlMGz6Ej678l2ApTdqDfsI0qBosfGpDb_jnVe2OaFCA7cKJ';
  final String baseUrl = 'https://api.currentsapi.services/v1';

  Future<Response> getLatestNews(int page) async {
    final response = await _dio.get(
      '$baseUrl/latest-news',
      queryParameters: {
        'apiKey': apiKey,
        'page_number': page,
      },
    );
    return response;
  }

  Future<Response> getNewsByCategory(String category, int page) async {
    final response = await _dio.get(
      '$baseUrl/latest-news',
      queryParameters: {
        'apiKey': apiKey,
        'category': category,
        'page_number': page,
      },
    );
    return response;
  }

  Future<Response> getNewsByRegion(String region, int page) async {
    final response = await _dio.get(
      '$baseUrl/latest-news',
      queryParameters: {
        'apiKey': apiKey,
        'country': region,
        'page_number': page,
      },
    );
    return response;
  }

  Future<Response> getNewsByLanguage(String language, int page) async {
    final response = await _dio.get(
      '$baseUrl/latest-news',
      queryParameters: {
        'apiKey': apiKey,
        'language': language,
        'page_number': page,
      },
    );
    return response;
  }

  Future<Response> getCategories() async {
    final response = await _dio.get(
      '$baseUrl/available/categories',
      queryParameters: {
        'apiKey': apiKey,
      },
    );
    return response;
  }

  Future<Response> getRegions() async {
    final response = await _dio.get(
      '$baseUrl/available/countries',
      queryParameters: {
        'apiKey': apiKey,
      },
    );
    return response;
  }

  Future<Response> getLanguages() async {
    final response = await _dio.get(
      '$baseUrl/available/languages',
      queryParameters: {
        'apiKey': apiKey,
      },
    );
    return response;
  }
}
