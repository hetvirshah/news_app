import 'package:dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:news/cubits/classfile.dart';

class NewsCubit extends Cubit<List<News>> {
  NewsCubit() : super([]);

  int currentPage = 1;
  bool isLoading = false;
  bool reachedEnd = false;
  final String apiKey = 'bUlMGz6Ej678l2ApTdqDfsI0qBosfGpDb_jnVe2OaFCA7cKJ';
  final Dio _dio = Dio();

  Future<void> fetchNews() async {
    if (isLoading || reachedEnd) return;

    isLoading = true;
    emit(List.from(state));

    try {
      Map<String, dynamic> queryParameters = {
        'apiKey': apiKey,
        'page': currentPage,
      };

      final response = await _dio.get(
        'https://api.currentsapi.services/v1/latest-news',
        queryParameters: queryParameters,
      );

      if (response.statusCode == 200) {
        var getData = response.data;
        var results = getData['news'];

        List<News> fetchedNews =
            (results as List).map((data) => News.fromJson(data)).toList();

        if (fetchedNews.isEmpty) {
          reachedEnd = true;
        } else {
          emit([...state, ...fetchedNews]);
          currentPage++;
        }
      } else {
        print('Failed to load news: ${response.statusCode}');
      }
    } catch (e) {
      print("Error: $e");
    } finally {
      isLoading = false;
    }
  }

  Future<void> fetchFilteredNews({
    String? category,
    String? language,
    String? country,
  }) async {
    if (isLoading || reachedEnd) return;

    try {
      isLoading = true;
      emit(state);

      Map<String, dynamic> queryParameters = {
        'apiKey': apiKey,
        'page': currentPage,
      };

      if (category != null) {
        queryParameters['category'] = category;
      }

      if (language != null) {
        queryParameters['language'] = language;
      }

      if (country != null) {
        queryParameters['country'] = country;
      }
      final response = await _dio.get(
        'https://api.currentsapi.services/v1/search',
        queryParameters: queryParameters,
      );
      print(response);

      if (response.statusCode == 200) {
        var getData = response.data;
        var results = getData['news'];

        List<News> fetchedNews =
            (results as List).map((data) => News.fromJson(data)).toList();

        emit([...state, ...fetchedNews]);

        if (fetchedNews.isEmpty) {
          reachedEnd = true;
        }

        currentPage++;
      } else {
        print('Failed to load news: ${response.statusCode}');
      }
    } catch (e) {
      print("Error: $e");
    } finally {
      isLoading = false;
      emit(state);
    }
  }
}

class RegionsCubit extends Cubit<List<Region>> {
  RegionsCubit() : super([]);

  final Dio _dio = Dio();

  Future<void> fetchRegions() async {
    try {
      emit(state);

      final response = await _dio.get(
        'https://api.currentsapi.services/v1/available/regions',
      );

      if (response.statusCode == 200) {
        var getData = response.data;
        var results = getData['regions'] as Map<String, dynamic>;

        List<Region> fetchedRegions = results.entries
            .map((entry) => Region.fromJson({
                  'name': entry.key,
                  'queryCode': entry.value,
                }))
            .toList();

        emit(fetchedRegions);
      } else {
        print('Failed to load regions: ${response.statusCode}');
      }
    } catch (e) {
      print("Error: $e");
    }
  }
}

class LanguageCubit extends Cubit<List<Language>> {
  LanguageCubit() : super([]);

  final Dio _dio = Dio();

  Future<void> fetchLanguages() async {
    try {
      emit(state);

      final response = await _dio.get(
        'https://api.currentsapi.services/v1/available/languages',
      );

      if (response.statusCode == 200) {
        var getData = response.data;
        var results = getData['languages'] as Map<String, dynamic>;

        List<Language> fetchedLanguages = results.entries
            .map((entry) => Language.fromJson({
                  'name': entry.key,
                  'queryCode': entry.value,
                }))
            .toList();

        emit(fetchedLanguages);
      } else {
        print('Failed to load regions: ${response.statusCode}');
      }
    } catch (e) {
      print("Error: $e");
    }
  }
}

class CategoriesCubit extends Cubit<List<Category>> {
  final Dio _dio = Dio();

  CategoriesCubit() : super([]);

  Future<void> fetchCategories() async {
    try {
      emit(state);
      final response = await _dio.get(
        'https://api.currentsapi.services/v1/available/categories',
      );

      if (response.statusCode == 200) {
        var getData = response.data;
        List<dynamic> categoriesData = getData['categories'];

        List<Category> fetchedCategories = categoriesData
            .map((category) => Category.fromJson({'name': category}))
            .toList();

        emit(fetchedCategories);
      } else {
        print('Failed to load categories: ${response.statusCode}');
      }
    } catch (e) {
      print("Error: $e");
    }
  }
}
