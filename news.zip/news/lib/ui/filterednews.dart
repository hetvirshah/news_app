import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:news/cubits/cubit.dart';
import 'package:news/ui/news_card.dart';

class FilteredNewsList extends StatelessWidget {
  final ScrollController _scrollController = ScrollController();
  final String category;
  final String language;
  final String country;
  FilteredNewsList(
      {Key? key, this.category = '', this.language = '', this.country = ''})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => NewsCubit(),
      child: Builder(builder: (context) {
        final newsCubit = context.watch<NewsCubit>();
        // Fetch news initially with the specified parameters
        if (newsCubit.state.isEmpty) {
          newsCubit.fetchFilteredNews(
              category: category, language: language, country: country);
        }
        return Scaffold(
          appBar: AppBar(),
          body: Column(
            children: [
              Expanded(
                child: NotificationListener<ScrollNotification>(
                  onNotification: (ScrollNotification scrollInfo) {
                    if (!newsCubit.isLoading &&
                        !newsCubit.reachedEnd &&
                        scrollInfo.metrics.pixels ==
                            scrollInfo.metrics.maxScrollExtent) {
                      newsCubit.fetchFilteredNews(
                          category: category,
                          language: language,
                          country: country);
                    }
                    return true;
                  },
                  child: ListView.builder(
                    controller: _scrollController,
                    itemCount:
                        newsCubit.state.length + (newsCubit.reachedEnd ? 0 : 1),
                    itemBuilder: (context, index) {
                      if (index < newsCubit.state.length) {
                        return NewsCard(news: newsCubit.state[index]);
                      } else if (!newsCubit.reachedEnd && newsCubit.isLoading) {
                        return Center(
                          child: CircularProgressIndicator(),
                        );
                      } else {
                        return SizedBox.shrink();
                      }
                    },
                  ),
                ),
              ),
              if (newsCubit.isLoading && !newsCubit.reachedEnd)
                Container(
                  padding: EdgeInsets.all(16),
                  alignment: Alignment.center,
                  child: CircularProgressIndicator(),
                ),
            ],
          ),
        );
      }),
    );
  }
}
