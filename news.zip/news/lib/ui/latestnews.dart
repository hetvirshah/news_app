import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:news/cubits/cubit.dart';
import 'package:news/ui/news_card.dart';

class NewsList extends StatelessWidget {
  final ScrollController _scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => NewsCubit()..fetchNews(),
      child: Builder(builder: (context) {
        final newsCubit = context.watch<NewsCubit>();
        final state = newsCubit.state;

        return Scaffold(
          body: Column(
            children: [
              Expanded(
                child: NotificationListener<ScrollNotification>(
                  onNotification: (ScrollNotification scrollInfo) {
                    if (!newsCubit.isLoading &&
                        !newsCubit.reachedEnd &&
                        scrollInfo.metrics.pixels ==
                            scrollInfo.metrics.maxScrollExtent) {
                      print('Fetching more news');

                      newsCubit.fetchNews();
                    }
                    return true;
                  },
                  child: state.isEmpty
                      ? Center(child: CircularProgressIndicator())
                      : ListView.builder(
                          controller: _scrollController,
                          itemCount:
                              state.length + (newsCubit.reachedEnd ? 0 : 1),
                          itemBuilder: (context, index) {
                            // Handle empty list
                            if (state.isEmpty) {
                              return Center(child: CircularProgressIndicator());
                            }

                            // Conditional access to avoid RangeError
                            return index < state.length
                                ? NewsCard(news: state[index])
                                : (newsCubit.isLoading && !newsCubit.reachedEnd)
                                    ? Center(child: CircularProgressIndicator())
                                    : SizedBox.shrink();
                          },
                        ),
                ),
              ),
              if (newsCubit.isLoading && !newsCubit.reachedEnd)
                Container(
                  padding: EdgeInsets.all(16),
                  alignment: Alignment.center,
                  child: CircularProgressIndicator(),
                ),
            ],
          ),
        );
      }),
    );
  }
}
