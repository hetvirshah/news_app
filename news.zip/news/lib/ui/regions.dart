import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:news/cubits/classfile.dart';
import 'package:news/cubits/cubit.dart';
import 'package:news/ui/filterednews.dart';

class RegionsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => RegionsCubit()..fetchRegions(),
      child: Scaffold(
        body: BlocBuilder<RegionsCubit, List<Region>>(
            builder: (context, regions) {
          if (regions.isEmpty) {
            return Center(child: CircularProgressIndicator());
          }

          return GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 3,
            ),
            itemCount: regions.length,
            itemBuilder: (context, index) {
              final region = regions[index];
              return GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          FilteredNewsList(country: region.queryCode)),
                ),
                child: Card(
                  child: Center(
                    child: Text(
                      region.name,
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                ),
              );
            },
          );
        }),
      ),
    );
  }
}
